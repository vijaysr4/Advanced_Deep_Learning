# Lab 7: Human motion generation

## Advanced deep learning

Check assignment [here](lab7_CSC52087EP.pdf), and run code [here](lab7_CSC52087EP.ipynb).